exports.port=3000
exports.url='mongodb://rbsuser1:rbs123@localhost:port/pmtdb?authSource=admin'
exports.user='rbsuser'
exports.password='rbs@123'
