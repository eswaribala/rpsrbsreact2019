/**
 * Created by BALASUBRAMANIAM on 06/09/2017.
 */
var mongoose = require('mongoose');
var configRef=require('./dbconfig')
console.log('Module is ready');

//1.Create schema
var projectSchema=new mongoose.Schema(
    {
        projectId:{type:Number,
            unique:true
        },
        projectName:String,
        location:String

    });



module.exports.ProjectModel=mongoose.model('ProjectModel',projectSchema);

